"""classification_loan
"""

__version__ = "0.1"
