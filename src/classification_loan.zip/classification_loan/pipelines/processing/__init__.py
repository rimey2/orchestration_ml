
# --- src/classification_loan/pipelines/processing/__init__.py ---
from .pipeline import create_pipeline