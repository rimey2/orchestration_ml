# --- src/classification_loan/pipelines/training/__init__.py ---
from .pipeline import create_pipeline